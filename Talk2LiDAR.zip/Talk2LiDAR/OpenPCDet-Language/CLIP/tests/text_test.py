import clip
import numpy as np

text = "there he is, follow that white car!"
clip_token = clip.tokenize(text.strip(), truncate=True)
print(type(clip_token))
print(clip_token.shape)

'''
max_index = clip_token.argmax()
max_index_np = np.array(max_index.item() - 1)
print(max_index_np)
print(type(max_index_np))

'''
device = "cuda"
clip_model, preprocess = clip.load("ViT-B/32", device=device)
word_features, sentence_features = clip_model.encode_text(clip_token)
print(word_features.shape)  # [1 77 512]
print(sentence_features.shape)  # [1 512]